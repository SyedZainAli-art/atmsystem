

import java.io.IOException;

public class ATM extends OptionMenu {

	public static void main(String[] args) throws IOException {
		OptionMenu optionMenu = new OptionMenu();

		optionMenu.getLogin();
		Account a1=new Account();
		a1. setCustomerNumber(5);
		a1. setCustomerNumber("zain");
		
	}

};
